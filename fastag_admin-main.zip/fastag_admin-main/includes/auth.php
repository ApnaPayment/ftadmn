<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . "/../config/database.php";
require_once __DIR__ . "/helpers.php";

function require_login() {
    // ✅ only check for admin_id (email was causing redirect loop)
    if (empty($_SESSION['admin_id'])) {
        redirect("index.php");
    }
}

function is_user_manager() {
    if (!empty($_SESSION['role'])) {
        return $_SESSION['role'] === 'user';
    }
    return isset($_SESSION['admin_id']) && $_SESSION['admin_id'] === 'admin001';
}

function is_order_manager() {
    if (!empty($_SESSION['role'])) {
        return $_SESSION['role'] === 'orders';
    }
    return isset($_SESSION['admin_id']) && $_SESSION['admin_id'] === 'admin002';
}
?>
