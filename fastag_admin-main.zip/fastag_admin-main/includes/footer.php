<footer class="site-footer">
  <div class="footer-container">
    <!-- Footer Logo -->
    <div class="footer-logo">
      <img src="https://www.apnapayment.com/website/img/logo/ApnaPayment200White.png" alt="Company Logo">
    </div>
    <div>
     <!-- address details -->
      <p>Apna Payment Services Private Limited - A-40, KARDHANI,<br> GOVINDPURA,<br>
JAIPUR, RAJASTHAN, 302012,<br>
KARDHANI, Rajasthan, PIN: 302012<br>
GSTIN : 08AAVCA0650L1ZA</p>
</div>
    <!-- Copyright -->
    <p>&copy; <?php echo date("Y"); ?> Your Company. All Rights Reserved.</p>
  </div>
</footer>