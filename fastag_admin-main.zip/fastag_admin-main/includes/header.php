<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<nav class="navbar">
  <div class="nav-container">
    <!-- Logo -->
    <div class="nav-logo">
      <a href="dashboard.php">
        <img src="https://www.apnapayment.com/website/img/logo/ApnaPayment200White.png" alt="Company Logo">
      </a>
    </div>

    <!-- Logout button (always visible when logged in) -->
    <?php if (!empty($_SESSION['admin_id'])): ?>
      <div class="nav-logout">
        <a href="logout.php" class="btn-logout">Logout</a>
      </div>
    <?php endif; ?>
  </div>
</nav>
