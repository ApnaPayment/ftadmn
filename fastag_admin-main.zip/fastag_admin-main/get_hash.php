<?php
// Change "newpassword123" to your desired password
echo password_hash("password123", PASSWORD_DEFAULT);
?>